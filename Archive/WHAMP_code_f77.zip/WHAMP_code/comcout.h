***************************************************************
*
* File comcout.h 

      COMPLEX*16 X, EFL(3), BFL(3), D ,DX, DZ, DP, E(6,4)
      
      COMMON /COUT/ X, P, Z, EFL, BFL ,D, DX, DZ, DP, E, 
     +              VG(2),SG(2),RI(2),ENE
